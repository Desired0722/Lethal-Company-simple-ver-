# FIT2099 Assignment (Semester 1, 2024)
# Static Factory