package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;



/**
 * Represents an action for the Alien Bug to follow the Intern player.
 * @author Henry Ma Yee Lik
 * Modified by:
 */
public class FollowAction extends Action {
    /**
     * The Actor to be followed.
     */
    private final Actor target;

    /**
     * The destination Location where the Alien Bug will follow the Intern.
     */
    private final Location destination;

    /**
     * Constructor.
     *
     * @param target      the Actor to be followed
     * @param destination the destination Location where the Alien Bug will follow the Intern
     */
    public FollowAction(Actor target, Location destination) {
        this.target = target;
        this.destination = destination;
    }

    /**
     * Follows the target Actor to the destination Location.
     *
     * @param actor the Actor performing the action
     * @param map   the GameMap containing the Actor
     * @return a description of the action
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        map.moveActor(actor, destination);
        return actor + " follows " + target + ".";
    }

    /**
     * Returns a description of the action suitable for display in the menu.
     *
     * @param actor The actor performing the action.
     * @return A String describing the action suitable for display in the menu.
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " follows " + target;
    }
}