package game.terrain;

import edu.monash.fit2099.engine.positions.Ground;

/**
 * A class that represents bare dirt.<br>
 * @author Riordan D. Alfredo
 * Modified by:
 *
 */
public class Dirt extends Ground {

    public Dirt() {
        super('.');
    }
}