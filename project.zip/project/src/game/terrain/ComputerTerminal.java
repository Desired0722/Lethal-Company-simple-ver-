package game.terrain;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.BuyAction;
import game.item.ToiletPaperRoll;
import game.scraps.DragonSlayerSword;
import game.scraps.EnergyDrink;

/**
 * A class that represents a computer terminal.
 */
public class ComputerTerminal extends Ground {
    /**
     * Constructor.
     *
     */
    public ComputerTerminal() {
        super('=');
    }

    /**
     * Returns an ActionList with the possible actions that can be done with the computer terminal
     *
     * @param actor the Actor acting
     * @param location the current Location
     * @param direction the direction of the Actor
     * @return an ActionList with the possible actions that can be done with the computer terminal
     */
    @Override
    public ActionList allowableActions(Actor actor, Location location, String direction) {
        ActionList list = new ActionList();
        list.add(new BuyAction(new EnergyDrink())); // 20% chance to double the price
        list.add(new BuyAction(new DragonSlayerSword())); // 50% chance to not print the item
        list.add(new BuyAction(new ToiletPaperRoll())); // 75% chance to reduce the price to 1 credit
        return list;
    }
}