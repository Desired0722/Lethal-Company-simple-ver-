/**
 * Package for characters and associated files
 */
package game.characters;