package game.scraps;

import edu.monash.fit2099.engine.items.Item;

/**
 * Represents a metal sheet<br>
 * @author Tong Zhi Hao
 * Modified by:
 *
 */
public class MetalSheet extends Item {
    /***
     * Constructor.
     */
    public MetalSheet() {
        super("Metal Sheet",'%',true);
    }
}
