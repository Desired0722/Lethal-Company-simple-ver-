package game.scraps;

import edu.monash.fit2099.engine.items.Item;

/**
 * Represents a large bolt<br>
 * @author Tong Zhi Hao
 * Modified by:
 *
 */
public class LargeBolt extends Item {
    /***
     * Constructor.
     */
    public LargeBolt() {
        super("Large Bolt",'+',true);
    }
}
