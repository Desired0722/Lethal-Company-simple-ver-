package game.scraps;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import game.Utility;
import game.ables.Consumable;
import game.ables.Perishable;
import game.actions.ConsumeAction;

/**
 * Represents a Jar of Pickles<br>
 * @author Elyesa Tee Way Yien
 * Modified by:
 *
 */
public class JarOfPickles extends Item implements Consumable, Perishable {

    /***
     * Constructor.
     */
    public JarOfPickles() {
        super("Jar of Pickles", 'n', true);
    }

    /**
     * Returns an ActionList with only a ConsumeAction with the Jar of Pickles as argument
     *
     * @param owner the actor that owns the item
     * @return ActionList with a ConsumeAction
     */
    @Override
    public ActionList allowableActions(Actor owner) {
        ActionList actions = new ActionList();
        actions.add(consume());
        return actions;
    }

    /**
     * Heals the player for 1 point if the item is not expired, otherwise the player loses 1 HP
     *
     * @param owner Owner of the consumable
     */
    @Override
    public void effect(Actor owner) {
        if (!this.expired()) {
            owner.heal(1);
        } else {
            owner.hurt(1);
            System.out.println("It was expired!.");
        }
    }



    /**
     * Returns a ConsumeAction with the Jar of Pickles as argument
     *
     * @return ConsumeAction with the Jar of Pickles as argument
     */
    @Override
    public ConsumeAction consume() {
        return new ConsumeAction(this);
    }

    /**
     * Returns the item
     *
     * @return the item
     */
    @Override
    public Item returnItem() {
        return this;
    }

    /**
     * Returns true if the item is expired, otherwise false
     *
     * @return true if the item is expired, otherwise false
     */
    @Override
    public boolean expired() {
        int expired = Utility.generateNumber(0, 100);
        if (expired <= 50) {
            return true;
        } else {
            return false;
        }
    }


}
