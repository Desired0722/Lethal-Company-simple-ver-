package game.scraps;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import game.ables.Consumable;
import game.actions.ConsumeAction;

/**
 * Represents a Pot of Gold<br>
 *
 * @author Elyesa Tee Way Yien
 * Modified by:
 */
public class PotOfGold extends Item implements Consumable{
    /***
     * Constructor.
     */
    public PotOfGold() {
        super("Pot of Gold", '$', true);
    }




    /**
     * Adds 10 credits to the User's balance
     *
     * @param owner actor using the pot of gold
     */
    @Override
    public void effect(Actor owner) {
        owner.addBalance(10);
        System.out.println("You got 10 credits!");
    }

    /**
     * Returns a ConsumeAction with PotOfGold as argument
     *
     * @return new ConsumeAction with PotOfGold as argument
     */
    @Override
    public ConsumeAction consume() {
        return new ConsumeAction(this);
    }

    /**
     * Returns itself
     *
     * @return Pot Of Gold
     */
    @Override
    public Item returnItem() {
        return this;
    }

    /**
     * Returns a list of actions containing only ConsumeAction
     *
     * @param owner the actor that owns the item
     * @return the list of actions
     */
    @Override
    public ActionList allowableActions(Actor owner) {
        ActionList actions = new ActionList();
        actions.add(consume());
        return actions;
    }
}
