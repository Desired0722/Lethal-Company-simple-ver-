/**
 * Package for various types of scrap
 */
package game.scraps;