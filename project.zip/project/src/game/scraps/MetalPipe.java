package game.scraps;

/**
 * Represents a metal pipe<br>
 * @author Tong Zhi Hao
 * Modified by:
 *
 */
public class MetalPipe extends ScrapWeapon {
    /**
     * Constructor.

     */
    public MetalPipe() {
        super("Metal Pipe",'!',1,"whacks",20);
    }


}
