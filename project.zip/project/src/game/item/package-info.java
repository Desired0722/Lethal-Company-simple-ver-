/**
 * Package for miscellaneous items that are not scrap
 */
package game.item;