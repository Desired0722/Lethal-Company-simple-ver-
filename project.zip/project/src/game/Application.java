package game;

import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.FancyGroundFactory;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.World;
import game.characters.Player;
import game.creatures.*;
import game.flora.Inheritree;
import game.flora.SmallFruit;
import game.scraps.LargeBolt;
import game.scraps.MetalPipe;
import game.scraps.MetalSheet;
import game.scraps.PotOfGold;
import game.terrain.*;

import java.util.Arrays;
import java.util.List;

/**
 * The main class to start the game.<br>
 * @author Adrian Kristanto
 * Modified by:
 * @author Tong Zhi Hao
 * @author Henry Ma Yee Lik
 *
 */
public class Application {

    public static void main(String[] args) {

        World world = new World(new Display());

        FancyGroundFactory groundFactory = new FancyGroundFactory(new Dirt(),
                new Wall(), new Floor(), new Puddle());

        List<String> map = Arrays.asList(
                        "...~~~~.........~~~...........",
                        "...~~~~.......................",
                        "...~~~........................",
                        "..............................",
                        ".............#####............",
                        ".............#___#...........~",
                        ".............#___#..........~~",
                        ".............##_##.........~~~",
                        ".................~~........~~~",
                        "................~~~~.......~~~",
                        ".............~~~~~~~........~~",
                        "......~.....~~~~~~~~.........~",
                        ".....~~~...~~~~~~~~~..........",
                        ".....~~~~~~~~~~~~~~~~........~",
                        ".....~~~~~~~~~~~~~~~~~~~....~~");

        GameMap gameMap = new GameMap(groundFactory, map);
        world.addGameMap(gameMap);

        for (String line : FancyMessage.TITLE.split("\n")) {
            new Display().println(line);
            try {
                Thread.sleep(200);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }


//        gameMap.at(7, 9).addActor(new HuntsmanSpider());
        gameMap.at(15,7).addItem(new MetalPipe());
//        gameMap.at(15,10).setGround(new Inheritree());
        gameMap.at(25,6).setGround(new Crater(new AlienBugSpawner()));
        gameMap.at(25,7).setGround(new Crater(new AlienBugSpawner()));
        gameMap.at(25,8).setGround(new Crater(new AlienBugSpawner()));
        gameMap.at(25,9).setGround(new Crater(new AlienBugSpawner()));

        gameMap.at(15,5).setGround(new ComputerTerminal());

        gameMap.at(15,14).setGround(new Puddle());
//        gameMap.at(15,10).addActor(new SuspiciousAstronaut());
        Player player = new Player("Intern", '@', 4);
//        gameMap.at(14,10).addItem(new LargeBolt());
        world.addPlayer(player, gameMap.at(15, 6));
//        gameMap.at(16,6).addItem(new PotOfGold());
//        gameMap.at(14,11).addItem(new LargeBolt());
        gameMap.at(15,10).addItem(new LargeBolt());
        gameMap.at(15,10).addItem(new LargeBolt());
        gameMap.at(15,10).addItem(new LargeBolt());
        gameMap.at(15,10).addItem(new LargeBolt());
        gameMap.at(15,10).addItem(new LargeBolt());
        gameMap.at(15,10).addItem(new LargeBolt());



//        gameMap.at(14,9).addItem(new LargeBolt());
//        gameMap.at(15,11).addItem(new LargeBolt());
//        gameMap.at(15,9).addItem(new LargeBolt());
//        gameMap.at(16,11).addItem(new LargeBolt());
//        gameMap.at(16,10).addItem(new LargeBolt());
        gameMap.at(16,9).addItem(new PotOfGold());


        world.run();

        for (String line : FancyMessage.YOU_ARE_FIRED.split("\n")) {
            new Display().println(line);
            try {
                Thread.sleep(200);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }
    }

}
