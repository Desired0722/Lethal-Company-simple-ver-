/**
 * Package for al able interfaces
 */
package game.ables;