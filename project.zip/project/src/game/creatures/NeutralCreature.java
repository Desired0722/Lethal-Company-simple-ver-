package game.creatures;


import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actions.AttackAction;
import game.behaviours.HostileBehaviour;
import game.characters.Player;
import game.characters.Status;

/**
 * Represents a Neutral Creature this particular creature may turn hostile if specific event occurs<br>
 * @author Tong Zhi Hao
 * Modified by:
 *
 */
public abstract class NeutralCreature extends  Creature{
    /**
     * The player to be followed
     */
    protected Player player;

    /**
     * The constructor of the Creature class.
     *
     * @param name        the name of the Mob
     * @param displayChar the character that will represent the Mob in the display
     * @param hitPoints   the Actor's starting hit points
     */
    public NeutralCreature(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);
        this.addCapability(Status.NEUTRAL_TO_PLAYER);
    }

    /**
     * Returns all the actions that the other Actor can perform on this Actor
     * @param otherActor the Actor that might be performing attack
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return ActionList containing all the actions that the other Actor can perform on this Actor
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if (otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)) {
            actions.add(new AttackAction(this, direction));
        }
        return actions;
    }

    /**
     * Adds HostileBehaviour to the NeutralCreature
     */
    public void enrage(){
        this.addBehaviours("ATTACK",new HostileBehaviour());
        this.addPriorityKey("ATTACK");
    }
}
