/**
 * Package for mobs and spawners
 */
package game.creatures;