package game.creatures;
import game.behaviours.KillBehaviour;

/**
 * Represents Suspicious Astronaut
 * Modified by:
 * @author Henry Ma Yee Lik
 *
 */

public class SuspiciousAstronaut extends HostileCreature {
    /**
     * The constructor of the HostileCreature class.
     *
     */
    public SuspiciousAstronaut() {
        super("SuspiciousAstronaut", 'ඞ', 99, 999, "stabs", 100);
        this.addBehaviours("KILL",new KillBehaviour());
        this.addPriorityKey("KILL");
    }

}
