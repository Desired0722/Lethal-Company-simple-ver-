package game.flora;

import edu.monash.fit2099.engine.positions.Location;

/**
 * Represents an Inheritree<br>
 * @author Tong Zhi Hao
 * Modified by:
 *
 */
public class Inheritree extends FruitPlant{
    /**
     * The constructor of the Inheritree class.
     */
    public Inheritree() {
        super("Inheritree", 't',new SmallFruit());
    }

    /**
     * Tries to spawn fruit and increment age every tick. If the age is 5, the displayed character becomes 'T'.
     * The type of fruit spawned becomes LargeFruit
     *
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location) {
        if (this.getAge() == 5){
            this.setDisplayChar('T');
            this.setFruit(new LargeFruit());
        }

        this.spawnObject(location);
        this.incrementAge();

    }
}
