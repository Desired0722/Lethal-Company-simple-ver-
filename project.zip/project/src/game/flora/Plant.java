package game.flora;

import edu.monash.fit2099.engine.positions.Ground;

/**
 * Represents a plant<br>
 * @author Tong Zhi Hao
 * Modified by:
 *
 */
public abstract class Plant extends Ground {
    /**
     * Age of the plant
     */
    private int age;

    /**
     * Name of the plant
     */
    private String name;


    /**
     * The constructor of the Actor class.
     *
     * @param displayChar character to display for this type of terrain
     */
    public Plant(String name,char displayChar) {
        super(displayChar);
        this.name = name;
        this.age = 0;
    }

    /**
     * Gets the age
     *
     * @return Age
     */
    public int getAge() {
        return age;
    }

    /**
     * Sets the age
     *
     * @param age age
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * Increments age by 1
     */
    public void incrementAge(){
        this.age++;
    }

    /**
     * Gets the name
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name
     *
     * @param name name
     */
    public void setName(String name) {
        this.name = name;
    }
}
