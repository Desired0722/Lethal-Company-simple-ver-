/**
 * Package for flora and fruits
 */
package game.flora;