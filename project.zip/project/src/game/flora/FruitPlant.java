package game.flora;

import edu.monash.fit2099.engine.positions.Location;
import game.Utility;
import game.terrain.Spawnpoint;

/**
 * Represents a fruiting plant<br>
 * @author Tong Zhi Hao
 * Modified by:
 *
 */
public abstract class FruitPlant extends Plant implements Spawnpoint {

    /**
     * Fruit the plant produces
     */
    private Fruit fruit;

    /**
     * The constructor of the Actor class.
     *
     * @param name
     * @param displayChar character to display for this type of terrain
     */
    public FruitPlant(String name, char displayChar,Fruit fruit) {
        super(name, displayChar);
        this.fruit = fruit;
    }

    /**
     * Tries to spawn fruit
     * @param location the location of the spawnpoint
     */
    public void spawnObject(Location location){
        Location selected = getSpawnLocation(location);
        int roll = Utility.generateNumber(0,100);
        if (roll < this.fruit.getDropChance()){
            selected.addItem(this.fruit);
        }
    }

    /**
     * Returns the fruit
     * @return Fruit
     */
    public Fruit getFruit() {
        return fruit;
    }

    /**
     * Sets the fruit produced to a specified type
     * @param fruit The fruit
     */
    public void setFruit(Fruit fruit) {
        this.fruit = fruit;
    }
}
